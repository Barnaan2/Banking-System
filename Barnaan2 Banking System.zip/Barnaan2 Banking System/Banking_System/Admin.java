

import java.io.Serializable;
/*
This is Demo System Of Banking System Written In Java 
   By :-  Bernabas Tekklign;
  Gitub User Name:-  ----- "Barnaan2"
  Email Address  ------ "BarnaanTekalign@gmail.com"
   " CopyRigh t--- AllRight is Reserved"

*/
public class Admin extends Bank implements Serializable{
	static final long  serialVersionUID = 2L;
	private String password;

	public void set_password(String password){
		this.password = password;
	}
	String get_password() {
		return password;
	}

}