
class Employee extends Bank{
    private String position;
    private String qualification;
    private double salary; 
    private String working_hours;
}