

import java.util.Scanner;
/*
This is Demo System Of Banking System Written In Java 
   By :-  Bernabas Tekklign;
  Gitub User Name:-  ----- "Barnaan2"
  Email Address  ------ "BarnaanTekalign@gmail.com"
   " CopyRigh t--- AllRight is Reserved"

*/
public interface admin_interface {
	// this uses the object of employee to create employee object
	public void hireEmployee(int numberOfEmployee) throws Exception;
	public void fireEmployee(int id)throws Exception;
	public void paySalary(int id, Scanner input)throws Exception;
	public void numberOfEmployee();
	public void numberOfCustomer();
//	public void update_cusomerinfo();
//	public void update_employeeinfo();
}