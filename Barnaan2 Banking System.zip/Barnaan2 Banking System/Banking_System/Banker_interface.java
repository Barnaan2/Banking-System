

import java.util.Scanner;
/*
This is Demo System Of Banking System Written In Java 
   By :-  Bernabas Tekklign;
  Gitub User Name:-  ----- "Barnaan2"
  Email Address  ------ "BarnaanTekalign@gmail.com"
   " CopyRigh t--- AllRight is Reserved"

*/
public interface Banker_interface {
 // this method users customer class to add new customer to the system;
    public void addCustomer(int numberOfCust)throws Exception;
    public void checkBalance(int id)throws Exception;
    public void withdraw(int id, double amount)throws Exception;
    public void changePassword(Scanner Input);
    public void serveCustomer(Scanner Input);
    
   // public boolean report(int id, String name, String detail, String password);

}