

import java.io.File;
import java.util.Scanner;
import java.io.FileInputStream;
import java.io.ObjectInputStream;

/*
This is Demo System Of Banking System Written In Java 
   By :-  Bernabas Tekklign;
  Gitub User Name:-  ----- "Barnaan2"
  Email Address  ------ "BarnaanTekalign@gmail.com"
   " CopyRigh t--- AllRight is Reserved"

*/
public class Banker_method implements Banker_interface {
	static Scanner Input = new Scanner (System.in);
	static  int ID  = 0;
	public static  Banker  deserialize(String fileName){
		Banker  object = new Banker();
		try{ File files =  new File(fileName);
		FileInputStream output;
		output = new FileInputStream(files);
		ObjectInputStream input;
		input = new ObjectInputStream(output);
		object = (Banker) input.readObject();
		input.close();
		}

		catch(Exception e) {
			System.out.println(e.getMessage()); }
		return object; }

	public static Banker getObject(int id) {
		Banker object = new Banker();
		String filename = Methods.getFileName(id);
		object = deserialize(filename);
		return object;
	}
	public boolean checkPassword(int id) {
		ID = id;
		Banker banker = new Banker();
		banker = getObject(id);
		System.out.print("Enter your password: ");
		String password = Input.nextLine();
		String password1 = banker.get_password();
		if(password.equals(password1)) {
			return true;
		}
		else {
			return false;
		}
	}



	public void operations(Scanner Input) {
		System.out.println("");
		System.out.println("");
		System.out.println("         Choose operation you want to perform:");
		System.out.println("0.       Exit ");
		System.out.println("1.       Add Customers");
		System.out.println("2.       Serve Customers ");
		System.out.println("3.       Check Balance ");
		System.out.println("4.       Withdraw  ");
		System.out.println("5.       Change password ");
		System.out.println("6.       Logout ");
		try
		{
			int choice = Input.nextInt();
			int value = 0;
			switch(choice) {
			case 1:
				System.out.print("Number of Customer : ");
				value = Input.nextInt();
				addCustomer(value);
				break;
			case 2:
				serveCustomer(Input);
				break;
			case 3:
				checkBalance(ID);
				break;
			case 4:
				System.out.print("How much you want to Withdraw:  ");
				double values = Input.nextDouble();
				withdraw(ID,values);
				break;
			case 5: 
				changePassword(Input);
				break;
			case 6:
				System.out.println("logged out");
				Home_page.login(Input);
				break;
			case 0:
				System.out.println("  you exited");
				System.exit(0);
				break;
			default:
				System.out.println("please choose form 0 to 6");
				System.out.println("");
				System.out.println("");
				operations(Input);
				break;
			}
		}
		catch(Exception e) {

			System.out.println("Unsuported input try again");
			System.out.println("");
			System.out.println("");
			Scanner error = new Scanner(System.in);
			operations(error);
		}

	}




	// add customer 
	public void addCustomer(int numberOfCust) throws Exception {
		int  type = 3;
		if (numberOfCust <= 0) {
			throw new Exception ("please  enter a number greater than or equal to 1");
		}
		else{
			Methods.createObjectArray(type,numberOfCust);
			Methods.printIdnumbers();
			operations(Input);
		}
	}


	// providing service for customer
	public void serveCustomer(Scanner Input)	{
		System.out.println("		Choose Service To provide:");
		System.out.println("0.		Exit: ");
		System.out.println("1.		Check Balance : ");
		System.out.println("2.		Deposit : ");
		System.out.println("3. 		Withdraw : ");
		System.out.println("4. 		Transfer To Another Account:  ");
		System.out.println("5. 		Back to previous options : ");
		System.out.println("6. 		Logut : ");
		try
		{
			int choice = Input.nextInt();
			Customer_method obj = new Customer_method();
			switch(choice) {
			case 1:
				System.out.println("Account Number: ");
				int accNo = Input.nextInt();
				obj.checkBalance(accNo);
			case 2:
				System.out.println("Account Number: ");
				int accNs = Input.nextInt();
				System.out.println("Enter Amount: ");
				double amount1 = Input.nextDouble();
				obj.deposit(accNs,amount1);
				break;
			case 3:
				System.out.println("Account Number: ");
				int accN = Input.nextInt();
				System.out.println("Enter Amount: ");
				double amount = Input.nextDouble();
				obj.withdraw(accN,amount);
				break;
			case 4:
				System.out.println("Sender's Account Number: ");
				int sAcc = Input.nextInt();
				System.out.println("Receiver's Account Number: ");
				int rAcc = Input.nextInt();
				System.out.println("Enter Amount: ");
				double amounts = Input.nextDouble();
				obj.transfer(sAcc, rAcc, amounts);
				break;
			case 5:
				operations(Input);
				break;
			case 6:
				System.out.println("Logged out");
				Home_page.login(Input);
				break;
			case 0:
				System.out.println(" You exited");
				System.exit(0);
				break;
			default:
				System.out.println("Please choose form 0 to 6");
				serveCustomer(Input);
				break;
			}
		}
		catch(Exception e) {

			System.out.println("Unsuported input try again");
			Scanner er = new Scanner(System.in);
			serveCustomer(er);
		}

	}
	
	
	
	//change password
	public void changePassword(Scanner Input) {
		if(checkPassword(ID)) 
		{ 
			System.out.print("system this it" + ID);
			System.out.println("Enter your new password");
		    Input.nextLine();
		    String password;
			password = Input.nextLine();
			Banker obj = new Banker() ;
			obj = getObject(ID);
			obj.set_password(password);
			Methods.saveChanges(ID,obj);
			System.out.println("password changed Sucessfully");
			System.out.println("");
			System.out.println("");
			operations(Input);
			
		}
		else {
			System.out.println("Your password was Incorrect");
			System.out.println("");
			System.out.println("");
			operations(Input);
		}
	}



	// method
	public void checkBalance(int id)throws Exception {
		String check = Methods.getFileName(id);
		if(check == null) {
			throw new Exception("Account Number does Not Exist! try again");
		}
		else {
			Banker obj = new Banker();
			obj = getObject(id);
			System.out.println("Balance Is "+ obj.get_balance());
			System.out.println("");
			System.out.println("");
			operations(Input);
		}
	}

	


	//withdraw
	public void withdraw(int id, double amount)throws Exception {
		String check = Methods.getFileName(id);
		if(check == null) {
			throw new Exception("Account Number does Not Exist! try again");
		} else {
			Banker obj = new Banker();
			obj = getObject(id);
			double balance =obj.get_balance();
			double leftBalance = balance - amount;
			double minimumAllowedBalance = Admin_method.minimumAllowedBalance;
			if(leftBalance < minimumAllowedBalance) {
				throw new Exception("your balance is lower the set limit! please try lower amount");
			}
			else {
				balance =leftBalance;
				obj.set_balance(balance);
				Methods.saveChanges(id, obj);
				System.out.println("Operation was  sucessfully ");
				System.out.println("");
				System.out.println("");
				operations(Input);
			}
		}
	}

}
