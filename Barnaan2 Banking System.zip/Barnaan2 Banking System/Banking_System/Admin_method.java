
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.ObjectInputStream;
import java.util.Scanner;
/*
This is Demo System Of Banking System Written In Java 
   By :-  Bernabas Tekklign;
  Gitub User Name:-  ----- "Barnaan2"
  Email Address  ------ "BarnaanTekalign@gmail.com"
   " CopyRight--- AllRight is Reserved"

 */
public  class Admin_method extends Admin implements admin_interface {
	private static final long serialVersionUID = 100L;
	static int ID = 0;
	static Scanner Input = new Scanner(System.in);
	Methods obj = new Methods();

	// generate admin oblect
	public static  Admin getObject(int id) {
		Admin object = new Admin();
		String filename = Methods.getFileName(id);
		object = deserialize(filename);
		return object;
	}


	// deseralize the Admin object; i don't know how to add and delete admin;
	public static  Admin  deserialize(String fileName){
		Admin object = new  Admin();
		try{ File files =  new File(fileName);
		FileInputStream output;
		output = new FileInputStream(files);
		ObjectInputStream input;
		input = new ObjectInputStream(output);
		object = (Admin) input.readObject();
		input.close();
		}
		catch(Exception e) {
			System.out.println(e.getMessage()); }
		return object; 
	}


	public boolean checkPassword(int id) {
		ID = id;
		Admin admin = new Admin();
		admin = getObject(id);
		System.out.print("Enter your password: ");
		String password = Input.nextLine();
		String password1 = admin.get_password();
		if(password.equals(password1)) {
			return true;
		}
		else {
			return false;
		}
	}

	// every thing an admin do
	public void operations(Scanner Input) {
		System.out.println("     Choose operation you want to perform:");
		System.out.println("[0] ***********Exit ");
		System.out.println("[1] ***********Pay salary for Employee  ");
		System.out.println("[2] ***********Hire Employee ");
		System.out.println("[3] ***********Fire Employee  ");
		System.out.println("[4] ***********Check How many Employee you have  ");
		System.out.println("[5] ***********Check How many Customers  you have ");
		System.out.println("[6] ***********Change Password ");
		System.out.println("[7] ***********Check Specific Customer Information");
		System.out.println("[8] ***********Check Specific Employee Information");
		System.out.println("[9] ***********Print All Employees You Have ");
		System.out.println("[10]***********Print Customer You Have ");
		System.out.println("[11]***********Logout");
		System.out.println("");
		try
		{
			int choice = Input.nextInt();
			int value = 0;
			switch(choice) {
			case 1:
				System.out.print("Id Number of An Employee: ");
				value = Input.nextInt();
				paySalary(value,Input);
				break;
			case 2:
				System.out.println("Number of  Employee: ");
				value = Input.nextInt();
				hireEmployee(value);
				break;
			case 3:
				printEmployee();
				System.out.print("Id Number of Employee You want to Fire: ");
				value = Input.nextInt();
				fireEmployee(value);
				break;
			case 4:
				numberOfEmployee();
				operations(Input);
				break;
			case 5: 
				numberOfCustomer();
				operations(Input);
				break;
			case 6:
				changePassword(Input);
				operations(Input);
				break;
			case 7:
				System.out.print("Enter Account Number : ");
				int accno = Input.nextInt();
				Customer obj = new Customer();

				if(Home_page.Authenthicator(accno,3)) { 
					obj = Customer_method.getObject(accno); 
					Show(obj,1);}
				else {
					System.out.println("Account Number is Not correct");
					operations(Input);
				}
				break;
			case 8:
				System.out.print("Enter Id Number : ");
				int Id = Input.nextInt();
				Banker banker = new Banker();

				if(Home_page.Authenthicator(Id,2)) { 
					banker = Banker_method.getObject(Id); 
					Show(banker,2);}
				else {
					System.out.println("ID Number is Not correct");
					operations(Input);
				}
				break;
			case 9:
				printEmployee();
				operations(Input);
				break;
			case 10:
                 printCustomer();
                 operations(Input);
				break;
			case 11:
				System.out.println("Signed Out");
				Home_page.login(Input);
				break;
			case 0:
				System.out.println("  You Exited");
				System.exit(0);
				break;
			default:
				System.out.println("Please choose form [0] to [9]");
				operations(Input);
				break;
			}
		}
		catch(Exception e) {

			System.out.println(e.getMessage());
			Scanner error = new Scanner(System.in);
			operations(error);
		}
	}
	public void paySalary(int id, Scanner input) throws Exception {
		String fileName = Methods.getFileName(id);
		if(fileName.equals(null)) {
			throw new Exception("The Id Number Is Not Correct Please Try Again");
		}
		else {
			Banker banker = new Banker();
			banker = Banker_method.getObject(id);
			double salary = banker.get_salary();
			double balance = banker.get_balance();
			balance+=salary;
			banker.set_balance(balance);
			Methods.saveChanges(id, banker);
			System.out.println("You Paid Salary  Done Sucessfully");
			System.out.println("");
			System.out.println("");
			operations(Input);
		}
	}


	public void hireEmployee(int numberOfEmp) throws Exception {
		int  type = 2;
		if (numberOfEmp <= 0) {
			throw new Exception ("Please Enter Number Greater Than Or Equal To [1]");
		}
		else{
			Methods.createObjectArray(type,numberOfEmp);
			Methods.printIdnumbers();
			operations(Input);
		}
	}

	public void fireEmployee(int id) throws Exception {
		String fileName = Methods.getFileName(id);
		if(fileName == null) {
			throw new Exception("The Id Number Is Not Correct Please Try Again");
		}
		else {
			File fired = new File(fileName);
			fired.delete();
			Methods.delete(id);

			System.out.println("You Have Fired The Selected Employee");
			System.out.println("");
			System.out.println("");
			operations(Input);
		}
	}



	// I read the id number and the file relation if it returns null it means the employee is deleted
	public void numberOfCustomer() {
		try{
			int count = 0 ;
			String fileName = "accountNumber.txt";
			String data= "";
			BufferedReader cust = new BufferedReader(new FileReader(fileName));
			while((data = cust.readLine()) != null){
				int datas = Integer.parseInt(data);
				if(Methods.getFileName(datas) != null)
				{
					count++;
				}
			}
			cust.close();

			System.out.println("You Have : " + count  + " Customers " );
			System.out.println("");
			System.out.println("");
			operations(Input);
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
	}


	// count banker
	public void numberOfEmployee() {
		try{
			int count = 0 ;
			String fileName = "EmployeeId.txt";
			BufferedReader cust = new BufferedReader(new FileReader(fileName));
			String data ="";
			while((data = cust.readLine()) != null){
				int datas = Integer.parseInt(data);
				if(Methods.getFileName(datas) != null) {
					count++;}
			}
			cust.close();
			System.out.println("You Have : " + count  + " Employees " );
			System.out.println("");
			System.out.println("");
			operations(Input);
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
	}
	public void changePassword(Scanner Input) {
		if(checkPassword(ID)) {

			System.out.print("Enter Your New Password: ");
			Input.nextLine();
			String password = Input.nextLine();
			Admin objects = new Admin() ;
			objects.set_password(password);
			Methods.saveChanges(ID,objects);
			System.out.println("Password Changed Sucessfully");
			System.out.println("");
			System.out.println("");
			operations(Input);
		}
	}




	public boolean	checkId( int id) {
		String name = Methods.getFileName(id);
		boolean check;
		if(name == null) {
			check = false;
			return check;
		}
		else {
			check = true;
			return check;

		}
	}
	public <V>  void   Show(V obj, int type) {
		Scanner input = new Scanner(System.in);
		switch(type) {
		case 1:
			System.out.println("                NAME: "+((Customer) obj).get_name());
			System.out.println("                AGE: " + ((Customer) obj).get_age());
			System.out.println("                SEX: "+((Customer) obj).get_gender());
			System.out.println("                BALANCE: "+((Customer) obj).get_balance());
			System.out.println("                BARANCH: "+((Customer) obj).get_branch());
			System.out.println("                DATE OF REGSTRATION: "+((Customer) obj).get_date_of_regstration());
			System.out.println("                ACCOUNT CREATOR ID : "+((Customer) obj).account_creator());
			
			System.out.println("");
			System.out.println("");
			//System.out.println("LAST UPDATE: ");
			operations(input);
			break;
		case 2:
			System.out.println("               NAME: " +((Banker) obj).get_name());
			System.out.println("               AGE: " + ((Banker) obj).get_age());
			System.out.println("               SEX: " + ((Banker) obj).get_gender());
			System.out.println("			   BALANCE: " + ((Banker) obj).get_balance());
			System.out.println("			   SALARY: "+ ((Banker) obj).get_salary());
			System.out.println("			   BARANCH: " +((Banker) obj).get_branch());
			System.out.println("			   DATE OF REGSTRATION: " +((Banker) obj).get_date_of_regstration());
			System.out.println("			   POSITION  : " +((Banker) obj).get_position());
			System.out.println("			   QUALIFICATION : " +((Banker) obj).get_qualification());
			
			System.out.println("");
			System.out.println("");
			operations(input);
			break;

		}



	}
	public void printEmployee(){
		String fileName = "EmployeeId.txt";
		Banker obj = new Banker();
		//Banker_method object= new Banker_method();
		
		try	{
			int count = 0;
			BufferedReader cust = new BufferedReader(new FileReader(fileName));
			String data ="";
			System.out.println("All Employees you have are:");
			System.out.println("No   Name----------------Id");
			while((data = cust.readLine()) != null){
				int datas = Integer.parseInt(data);
			    if( Methods.getFileName(datas)!= null) 
			 {
			    	obj = Banker_method.getObject(datas);
			    	count++;
				System.out.println("[" +count + "]  "+ obj.get_name()+"-----"+ data);
				}
			}
			System.out.println("");
			System.out.println("");
			System.out.println("");
			cust.close();
		}
		catch(Exception e) {
			System.out.println(e.getMessage());
		}
	}
	
	
	public void printCustomer(){
		String fileName = "accountNumber.txt";
		Customer obj = new Customer();
		//Banker_method object= new Banker_method();
		
		try	{
			int count = 0;
			BufferedReader cust = new BufferedReader(new FileReader(fileName));
			String data ="";
			System.out.println("All Customer you have are:");
			System.out.println("No    Name--------------- Id");
			while((data = cust.readLine()) != null){
				int datas = Integer.parseInt(data);
			    if( Methods.getFileName(datas)!= null) 
			 {
			    	obj = Customer_method.getObject(datas);
			    	count++;
				System.out.println("[" +count + "]  "+ obj.get_name()+"-----"+ data);
				}
			}
			System.out.println("");
			System.out.println("");
			System.out.println("");
			cust.close();
		}
		catch(Exception e) {
			System.out.println(e.getMessage());
		}
	}
	static double minimumAllowedBalance = 25.00;


}
