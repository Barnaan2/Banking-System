           use command Line to run the class that contain Main method.     
            THE NAME OF THE CLASS CONTAIN MAIN METHOD IS -------[ Home_page.java]-----------


---------------------------BANKING SYSTEM SIMUALATION BY JAVA-------------------------------------------------
Code Writer -----------------BERANABAS TEKKALIGN-----------------------------------------------------------
gitub user name------------- @Barnaan2 ------email address-------------- BarnaanTekaling@gmail.com
 
  By using this system you can do  login as either Employee or as an Administrator
   As ilustration i set Admin id  and password in Home page.
  Also if you wish to use as Employee i have created one Employee and set its information in home page.

  ---------------------------------------------------------------------------------------------------------------

  An Admin user can do the following 

   1.Pay salary for Employee
   2.Hire Employee 
   3.Fire Employee  
   4.Check How many Employee exists in the system  
   5 .Check How many Customers  exists  in the system
   6.Change Password 
   8.Check Specific Customer Information
   9.Check Specific Employee Information
  10.Print All Employees  in the system
  11.Print Customer  in the system
  12.Logout of the Admin interaface to login as Employee or Exit
--------------------------------------------------------------------------------------------------------


An Employee can user can do the following

1. Add a new customer to the system
2. serve customer that are Already in the System
3. check balance of his / her own
4. withdraw money form his / her salary if there is some.
5.Change password 
6.logout of the Employee interface
 

Here the the "serve Customers" option in Number [2] also have another sub option to serve the customers:

1. check balance for a customer
2. deposit for customer
3. withdraw for customer
4. transfer (to send money to another customers account that is already in the system from another customer's account)
5. back to the previous option that listed above


---------this is just for demo purpose. fully funcitonal system still underdevelopment-------------
---------------------------------Thank you for checking---------------------------------------------
----------for any  comment and suggestions- email me  at BarnaanTekaling@gmail.com------------------